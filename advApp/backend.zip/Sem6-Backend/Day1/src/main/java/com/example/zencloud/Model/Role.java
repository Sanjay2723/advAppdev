package com.example.zencloud.Model;

public enum Role {
    USER,
    ADMIN
}
